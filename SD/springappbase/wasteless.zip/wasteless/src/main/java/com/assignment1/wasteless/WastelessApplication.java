package com.assignment1.wasteless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WastelessApplication {

	public static void main(String[] args) {
		SpringApplication.run(WastelessApplication.class, args);
	}

}
