package com.assignment1.wasteless;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WastelessApplicationTests {

	@Test
	void contextLoads() {
	}

}
